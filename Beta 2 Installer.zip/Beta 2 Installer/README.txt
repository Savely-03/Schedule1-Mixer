Hello Everyone!

This is my first ever personal coding project. I was a little disappointed with the recipe management in the hit game Schedule 1, created by Tyler, at TVGS, and wanted an easier way to track them.

I created this application as a way to help simulate the mixing with all of the effects properly tracked and a way for you to save it, as well as view it easily, so you can recreate it in game!

It should be pretty self-explanatory but if you have any questions feel free to add me on discord @savely.03
If you find any problems or have any suggestions I am open to hearing them, or if you find any room for improvement, let me know!!!

Step 1: Open and Run the Installer

Step 2: Choose a Base (Strain, Blank, Custom)

Step 3: Choose an Ingredient using the Drop Down Menu

Step 4: Mix

Step 5: Repeat 3-4 or Save

Step 6: Check that it saved properly ('Cook'book or Edit Custom Base)

Step 7: Experiment, Mess Around, try to break it. 

Step 8: Dude, wtf you broke my program?

Step 9: Report the Broken stuff on both Nexus and my GitHub so I can fix it

Step 9a (Optional): Try to fix the issue(s) yourself and let me know
